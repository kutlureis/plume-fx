package dev.plume

import android.content.SharedPreferences
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import org.json.JSONArray
import org.json.JSONObject

/**
 * One match for the home screen. [comp] is already in Turkish, [at] is the kick-off in epoch milliseconds,
 * [state] is 0 not started, 1 live, 2 finished, and [hs]/[aws] are the home and away goals (text).
 */
internal class Fixture(
    val comp: String, val home: String, val away: String, val at: Long,
    val state: Int, val hs: String, val aws: String,
)

/**
 * Two lists for the home screen: the next Süper Lig matches, and the Turkish clubs' matches in the three
 * European cups. Both come from ESPN's public scoreboard, which lists every match of a date range in one
 * answer. Nothing runs in the background: the home screen asks when it opens, and an answer is kept for
 * [EVERY_MS]. Only the few fields shown are saved, as a small JSON text in the launcher's preferences.
 */
internal object Fixtures {
    const val LEAGUE = 0
    const val EURO = 1

    private const val ESPN = "https://site.api.espn.com/apis/site/v2/sports/soccer/"
    private const val DAY = 24 * 3600_000L
    private const val EVERY_MS = 30 * 60_000L // the league list: scores move
    private const val EURO_EVERY_MS = 6 * 3600_000L // the European list: fixtures hardly move
    private const val DONE_MS = 10 * 3600_000L // a finished match stays listed this long, with its score
    private const val STALE_MS = 3 * 3600_000L // "not started" this long after kick-off means it is not being played
    private const val LEAGUE_DAYS = 10 // looks this many days ahead, stops earlier once the list is full
    private const val EURO_DAYS = 14
    private const val MAX = 12
    private const val KEY_LEAGUE = "fx_league"
    private const val KEY_EURO = "fx_euro"
    private const val STAMP = "fx_stamp"
    private const val STAMP_EURO = "fx_stamp_euro"

    private val CUPS = listOf(
        "uefa.champions" to "Şampiyonlar Ligi",
        "uefa.europa" to "Avrupa Ligi",
        "uefa.europa.conf" to "Konferans Ligi",
    )

    /** Turkish clubs, written without accents and in lower case: ESPN lists European matches of everyone. */
    private val TURKISH = listOf(
        "galatasaray", "fenerbah", "besiktas", "trabzonspor", "basaksehir", "samsunspor", "konyaspor",
        "rizespor", "kasimpasa", "goztepe", "alanyaspor", "antalyaspor", "kayserispor", "eyupspor",
        "gaziantep", "genclerbirligi", "karagumruk", "kocaelispor", "bodrum", "sivasspor", "hatayspor",
    )

    private val NAMES = mapOf(
        "İstanbul Başakşehir" to "Başakşehir", "Istanbul Basaksehir" to "Başakşehir",
        "Çaykur Rizespor" to "Rizespor", "Fatih Karagümrük" to "Karagümrük",
    )

    /** The shown name: the long official ones are cut down to fit a card. */
    fun nice(name: String) = NAMES[name] ?: name

    fun loaded(prefs: SharedPreferences) = prefs.getLong(STAMP, 0) > 0

    /** The saved list for [tab] ([LEAGUE] or [EURO]), soonest first. Never touches the network. */
    fun cached(prefs: SharedPreferences, tab: Int): List<Fixture> {
        val raw = prefs.getString(if (tab == EURO) KEY_EURO else KEY_LEAGUE, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val now = System.currentTimeMillis()
            (0 until arr.length()).map { arr.getJSONArray(it) }
                .map {
                    Fixture(it.getString(0), it.getString(1), it.getString(2), it.getLong(3), it.getInt(4), it.getString(5), it.getString(6))
                }
                .filter { shown(it.state, it.at, now) }
                .sortedBy { it.at }
                .take(MAX)
        } catch (ex: Exception) {
            emptyList()
        }
    }

    /**
     * Fetches the lists that are due. Blocks: call it off the UI thread. Returns true when a saved list changed.
     * With no answer from the server, the old lists stay. ESPN answers one day per request (a date range is
     * refused), so the league list walks the days until it is full, and the European list asks only for the
     * days European matches are played on (Tuesday to Thursday).
     */
    fun refresh(prefs: SharedPreferences): Boolean {
        val now = System.currentTimeMillis()
        val leagueDue = now - prefs.getLong(STAMP, 0) >= EVERY_MS
        val euroDue = now - prefs.getLong(STAMP_EURO, 0) >= EURO_EVERY_MS
        if (!leagueDue && !euroDue) return false
        var changed = false
        if (leagueDue) {
            val league = ArrayList<Fixture>()
            var reached = false
            for (d in -1..LEAGUE_DAYS) {
                if (league.size >= MAX) break
                val ok = readDay("tur.1", now + d * DAY, now, "Süper Lig", false, league)
                if (ok) reached = true else if (!reached) break // no answer at all: do not wait for every day
            }
            if (reached) {
                val json = pack(league)
                changed = json != prefs.getString(KEY_LEAGUE, null)
                prefs.edit().putString(KEY_LEAGUE, json).putLong(STAMP, now).apply()
            }
        }
        if (euroDue) {
            val euro = ArrayList<Fixture>()
            var reached = false
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            loop@ for ((slug, name) in CUPS) {
                for (d in -1..EURO_DAYS) {
                    cal.timeInMillis = now + d * DAY
                    val dow = cal.get(Calendar.DAY_OF_WEEK)
                    if (dow != Calendar.TUESDAY && dow != Calendar.WEDNESDAY && dow != Calendar.THURSDAY) continue
                    val ok = readDay(slug, now + d * DAY, now, name, true, euro)
                    if (ok) reached = true else if (!reached) break@loop
                }
            }
            if (reached) {
                val json = pack(euro)
                if (json != prefs.getString(KEY_EURO, null)) changed = true
                prefs.edit().putString(KEY_EURO, json).putLong(STAMP_EURO, now).apply()
            }
        }
        return changed
    }

    /** "Bugün 20:00", "Yarın 20:00" or the short day name and the time, in the TV's time zone. */
    fun whenText(at: Long, now: Long): String {
        val day = Calendar.getInstance().apply { timeInMillis = at }
        val today = Calendar.getInstance().apply { timeInMillis = now }
        fun key(c: Calendar) = c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
        val clock = String.format(Locale.US, "%02d:%02d", day.get(Calendar.HOUR_OF_DAY), day.get(Calendar.MINUTE))
        val name = when (key(day) - key(today)) {
            0 -> "Bugün"
            1 -> "Yarın"
            else -> SimpleDateFormat("EEE", Locale("tr", "TR")).format(Date(at))
        }
        return "$name $clock"
    }

    private fun shown(state: Int, at: Long, now: Long) = when (state) {
        2 -> at > now - DONE_MS
        0 -> at > now - STALE_MS
        else -> true
    }

    private fun pack(list: List<Fixture>): String {
        val out = JSONArray()
        list.distinctBy { "${it.at}|${it.home}|${it.away}" }.sortedBy { it.at }.take(MAX).forEach {
            out.put(JSONArray().put(it.comp).put(it.home).put(it.away).put(it.at).put(it.state).put(it.hs).put(it.aws))
        }
        return out.toString()
    }

    /** Reads the scoreboard of one day into [out]. False when no answer came. */
    private fun readDay(slug: String, day: Long, now: Long, comp: String, onlyTurkish: Boolean, out: MutableList<Fixture>): Boolean {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val root = get("$ESPN$slug/scoreboard?dates=" + f.format(Date(day))) ?: return false
        val events = root.optJSONArray("events") ?: return true
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val c = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val teams = c.optJSONArray("competitors") ?: continue
            var home = ""
            var away = ""
            var hs = ""
            var aws = ""
            for (j in 0 until teams.length()) {
                val t = teams.optJSONObject(j) ?: continue
                val name = t.optJSONObject("team")?.optString("displayName").orEmpty()
                if (t.optString("homeAway") == "home") {
                    home = name
                    hs = t.optString("score")
                } else {
                    away = name
                    aws = t.optString("score")
                }
            }
            if (home.isEmpty() || away.isEmpty()) continue
            if (onlyTurkish && !turkish(home) && !turkish(away)) continue
            val at = parse(e.optString("date")) ?: continue
            val state = when (c.optJSONObject("status")?.optJSONObject("type")?.optString("state")) {
                "in" -> 1
                "post" -> 2
                else -> 0
            }
            if (!shown(state, at, now)) continue
            out.add(Fixture(comp, home, away, at, state, hs, aws))
        }
        return true
    }

    private fun turkish(name: String): Boolean {
        val n = name.lowercase(Locale.ROOT)
            .replace('ı', 'i').replace('ö', 'o').replace('ü', 'u').replace('ç', 'c').replace('ş', 's').replace('ğ', 'g')
            .replace("\u0307", "")
        return TURKISH.any { it in n }
    }

    /** ESPN writes the kick-off in UTC, as 2026-10-30T17:00Z. */
    private fun parse(s: String): Long? {
        if (s.length < 16) return null
        return try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }
                .parse(s.substring(0, 16))?.time
        } catch (ex: Exception) {
            null
        }
    }

    /**
     * One GET. The connection is not closed on purpose: Android keeps it and the next request to ESPN reuses it,
     * so the 5-20 day requests of a refresh share one TLS handshake instead of paying for one each.
     */
    private fun get(url: String): JSONObject? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "Plume")
            if (c.responseCode != 200) {
                c.errorStream?.close()
                return null
            }
            val bytes = c.inputStream.use { it.readBytes() }
            // ESPN may send gzip even when not asked: unpack it by hand when the first two bytes say so
            val gzip = bytes.size > 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
            val text = if (gzip) java.util.zip.GZIPInputStream(bytes.inputStream()).use { it.readBytes() }.decodeToString()
                else bytes.decodeToString()
            JSONObject(text)
        } catch (ex: Exception) {
            null
        }
    }
}
