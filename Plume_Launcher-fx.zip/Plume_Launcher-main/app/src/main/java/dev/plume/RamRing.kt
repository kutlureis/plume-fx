package dev.plume

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View

private val RING_GREEN = 0xFF3DDC84.toInt()
private val RING_AMBER = 0xFFFFB300.toInt()
private val RING_RED = 0xFFFF453A.toInt()

/**
 * Free RAM as a ring. The ring fills as memory is used, and turns amber and then red near the top.
 * The number inside is the free memory in MB. It draws two arcs and two short texts: no bitmaps.
 */
class RamRing(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3 * d
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 11 * d
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val unit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 7 * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private var used = 0f
    private var free = 0

    /** Colour of the number and the track; the home screen picks white or near-black to stand out from the wallpaper. */
    var ink = Color.WHITE
        set(value) {
            field = value
            invalidate()
        }

    /** [freeMb] and [totalMb] in MB. */
    fun show(freeMb: Int, totalMb: Int) {
        free = freeMb
        used = if (totalMb > 0) (1f - freeMb.toFloat() / totalMb).coerceIn(0f, 1f) else 0f
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (isFocused) { // selected with the remote: a soft disc behind the ring, like the other top icons
            fill.color = (ink and 0xFFFFFF) or (0x40 shl 24)
            c.drawCircle(width / 2f, height / 2f, width / 2f, fill)
        }
        val pad = 3 * d
        box.set(pad, pad, width - pad, height - pad)
        track.color = (ink and 0xFFFFFF) or (0x33 shl 24)
        c.drawArc(box, 0f, 360f, false, track)
        arc.color = when {
            used < 0.75f -> RING_GREEN
            used < 0.88f -> RING_AMBER
            else -> RING_RED
        }
        c.drawArc(box, -90f, 360f * used, false, arc)
        num.color = ink
        unit.color = (ink and 0xFFFFFF) or (0xB3 shl 24)
        val cx = width / 2f
        c.drawText(free.toString(), cx, height / 2f + 1 * d, num)
        c.drawText("MB", cx, height / 2f + 9 * d, unit)
    }
}
