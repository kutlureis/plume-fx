package dev.plume

import android.content.SharedPreferences
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import org.json.JSONArray
import org.json.JSONObject

/** One match for the home screen. [comp] is already in Turkish; [at] is the kick-off in epoch milliseconds. */
internal class Fixture(val comp: String, val home: String, val away: String, val at: Long)

/**
 * The next Süper Lig matches, and the next European matches of the Turkish clubs, from TheSportsDB's free
 * keyless test key. Nothing runs in the background: the home screen asks when it opens, and the answer is
 * kept for [EVERY_MS]. The list is saved in the launcher's preferences as a small JSON text.
 */
internal object Fixtures {
    private const val BASE = "https://www.thesportsdb.com/api/v1/json/123/"
    private const val LEAGUE = "4339" // Turkish Super Lig
    private val TEAMS = listOf("Galatasaray", "Fenerbahce", "Besiktas", "Trabzonspor", "Istanbul Basaksehir")
    private const val DAY = 24 * 3600_000L
    private const val EVERY_MS = 3 * 3600_000L
    private const val LIVE_MS = 3 * 3600_000L // a match stays listed this long after kick-off
    private const val LEAGUE_DAYS = 8
    private const val EURO_DAYS = 14
    private const val MAX = 14
    private const val KEY = "fx_json"
    private const val STAMP = "fx_time"

    private val NAMES = mapOf(
        "Fenerbahce" to "Fenerbahçe", "Besiktas" to "Beşiktaş", "Istanbul Basaksehir" to "Başakşehir",
        "Basaksehir" to "Başakşehir", "Kasimpasa" to "Kasımpaşa", "Goztepe" to "Göztepe",
        "Genclerbirligi" to "Gençlerbirliği", "Eyupspor" to "Eyüpspor", "Karagumruk" to "Karagümrük",
        "Fatih Karagumruk" to "Karagümrük", "Caykur Rizespor" to "Rizespor", "Gaziantep FK" to "Gaziantep",
    )

    /** The shown name: TheSportsDB writes Turkish names without their accents. */
    fun nice(name: String) = NAMES[name] ?: name

    /** The saved list: matches that have not finished, soonest first. Never touches the network. */
    fun cached(prefs: SharedPreferences): List<Fixture> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val now = System.currentTimeMillis()
            (0 until arr.length()).map { arr.getJSONArray(it) }
                .map { Fixture(it.getString(0), it.getString(1), it.getString(2), it.getLong(3)) }
                .filter { it.at > now - LIVE_MS }
                .sortedBy { it.at }
                .take(MAX)
        } catch (ex: Exception) {
            emptyList()
        }
    }

    /**
     * Fetches when the saved list is older than [EVERY_MS]. Blocks: call it off the UI thread.
     * Returns true when the saved list changed. With no answer from the server, the old list stays.
     */
    fun refresh(prefs: SharedPreferences): Boolean {
        val now = System.currentTimeMillis()
        if (now - prefs.getLong(STAMP, 0) < EVERY_MS) return false
        val found = ArrayList<Fixture>()
        var reached = false
        val league = get("eventsnextleague.php?id=$LEAGUE")
        if (league != null) {
            reached = true
            val next = events(league)
            for (e in next) {
                val at = time(e) ?: continue
                if (at > now + LEAGUE_DAYS * DAY) continue
                found.add(Fixture("Süper Lig", e.optString("strHomeTeam"), e.optString("strAwayTeam"), at))
            }
            // The free key can answer with a match or two only: fill the week from the round's own list.
            if (found.size < 5) {
                val first = next.firstOrNull()
                val round = first?.optString("intRound")?.toIntOrNull()
                val season = first?.optString("strSeason").orEmpty()
                if (round != null && season.isNotEmpty()) for (r in round..round + 1) {
                    val res = get("eventsround.php?id=$LEAGUE&r=$r&s=" + URLEncoder.encode(season, "UTF-8")) ?: continue
                    for (e in events(res)) {
                        val at = time(e) ?: continue
                        if (at < now - LIVE_MS || at > now + LEAGUE_DAYS * DAY) continue
                        found.add(Fixture("Süper Lig", e.optString("strHomeTeam"), e.optString("strAwayTeam"), at))
                    }
                }
            }
        }
        for (name in TEAMS) {
            val id = teamId(prefs, name) ?: continue
            val res = get("eventsnext.php?id=$id") ?: continue
            reached = true
            for (e in events(res)) {
                val comp = competition(e.optString("strLeague")) ?: continue // only the European cups: the league has its own call
                val at = time(e) ?: continue
                if (at > now + EURO_DAYS * DAY) continue
                found.add(Fixture(comp, e.optString("strHomeTeam"), e.optString("strAwayTeam"), at))
            }
        }
        if (!reached) return false
        val list = found.distinctBy { "${it.at}|${it.home}|${it.away}" }.sortedBy { it.at }.take(MAX)
        val json = JSONArray().apply {
            for (f in list) put(JSONArray().put(f.comp).put(f.home).put(f.away).put(f.at))
        }.toString()
        val changed = json != prefs.getString(KEY, null)
        prefs.edit().putString(KEY, json).putLong(STAMP, now).apply()
        return changed
    }

    /** "Bugün 20:00", "Yarın 20:00" or the short day name and the time, in the TV's time zone. */
    fun whenText(at: Long, now: Long): String {
        val day = Calendar.getInstance().apply { timeInMillis = at }
        val today = Calendar.getInstance().apply { timeInMillis = now }
        fun key(c: Calendar) = c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
        val clock = String.format(Locale.US, "%02d:%02d", day.get(Calendar.HOUR_OF_DAY), day.get(Calendar.MINUTE))
        val name = when (key(day) - key(today)) {
            0 -> "Bugün"
            1 -> "Yarın"
            else -> SimpleDateFormat("EEE", Locale("tr", "TR")).format(Date(at))
        }
        return "$name $clock"
    }

    private fun competition(league: String): String? {
        val l = league.lowercase(Locale.US)
        return when {
            "champions" in l -> "Şampiyonlar Ligi"
            "conference" in l -> "Konferans Ligi" // before "europa": its full name has both
            "europa" in l -> "Avrupa Ligi"
            else -> null
        }
    }

    private fun events(o: JSONObject): List<JSONObject> {
        val a = o.optJSONArray("events") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    }

    /** Kick-off as epoch milliseconds. TheSportsDB gives the time in UTC. */
    private fun time(e: JSONObject): Long? {
        val stamp = e.optString("strTimestamp").takeIf { it.length >= 19 }
            ?: (e.optString("dateEvent") + "T" + e.optString("strTime")).takeIf { it.length >= 19 }
            ?: return null
        return try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }
                .parse(stamp.substring(0, 19))?.time
        } catch (ex: Exception) {
            null
        }
    }

    /** The club's id, looked up once by name and then kept. */
    private fun teamId(prefs: SharedPreferences, name: String): String? {
        prefs.getString("fx_id_$name", null)?.let { return it }
        val res = get("searchteams.php?t=" + URLEncoder.encode(name, "UTF-8").replace("+", "%20")) ?: return null
        val list = res.optJSONArray("teams") ?: return null
        for (i in 0 until list.length()) {
            val t = list.optJSONObject(i) ?: continue
            val country = t.optString("strCountry").lowercase(Locale.US)
            if (t.optString("strSport") == "Soccer" && (country == "turkey" || country == "türkiye" || country == "turkiye")) {
                val id = t.optString("idTeam")
                if (id.isNotEmpty()) {
                    prefs.edit().putString("fx_id_$name", id).apply()
                    return id
                }
            }
        }
        return null
    }

    private fun get(path: String): JSONObject? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(BASE + path).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Plume")
            if (c.responseCode == 200) JSONObject(c.inputStream.use { it.readBytes().decodeToString() }) else null
        } catch (ex: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }
}
